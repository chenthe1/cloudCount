package com.lance.application;

import java.util.concurrent.Callable;

public class CrawlerCall implements Callable<String>{
	
	public String call() throws Exception {
		
		return null;
	}
}
